# Express CRUD Lab - [Nama Anda]

## Deskripsi
Aplikasi API untuk mengelola data buku menggunakan Express.js, Mongoose, dan MongoDB.

## Cara Menjalankan
1. Pastikan MongoDB sudah berjalan.
2. Install dependencies: `npm install`
3. Jalankan server: `node app.js`

## Fitur
- Create, Read, Update, Delete data buku.
-